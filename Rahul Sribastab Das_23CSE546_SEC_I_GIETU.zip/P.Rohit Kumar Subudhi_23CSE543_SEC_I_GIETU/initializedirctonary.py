my_dict={
    "name":"Rohit Kumar",
    "age": 21,
    "city": "Berhampur"
}
print(my_dict)