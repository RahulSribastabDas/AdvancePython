book_author_price={
    "The Great Gatesby":{
        "author":"Rohit Kumar",
        "price":2999
    },
    "To kill a Mockingbird":{
        "author":"Ashutosh Sahu",
        "price":1999
    },
    "rich dad poor dad":{
        "author":"Robert Kiyosaki",
        "price":1499
    }
}
print(book_author_price)