dict={
    "name":"Rohit Kumar",
    "age": 21,
    "city": "Berhampur"
}
print(dict)
print(len(dict))
print(type(dict))
print(dict["name"])
dict["age"]
print(dict)
dict["profession"]="Student"
print(dict)
del dict["city"]